function [equal]=convergence_criterium(tol, old_estimates, estimates)

is_equal=zeros(size(estimates,1),size(estimates,2));
if size(old_estimates,1)==size(estimates,1) && size(old_estimates,2)==size(estimates,2)
    for i=1:size(estimates,1)
        for j=1:size(estimates,2)
            if abs(old_estimates(i,j)/estimates(i,j))<=(1+tol) && abs(estimates(i,j)/old_estimates(i,j))<=(1+tol)
                is_equal(i,j)=1;
            end
        end
    end
    the_sum=sum(is_equal,'all');
    if the_sum==(size(estimates,1)*size(estimates,2))
        equal=1;
    else
        equal=0;
    end
else
    equal=0;
end