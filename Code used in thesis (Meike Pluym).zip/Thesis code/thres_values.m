function [sse, thresValues]=thres_values(X, y, thres)
global p

thres_group=X(:,(p/2)+1);
X=X(:,1:p/2);
%DIT MOET NOG PER GROEP KUNNEN
Xrows=size(X,1);
Xcols=size(X,2);

thSort=sort(thres); %sort the threshold (increasing)
thSort=unique(thSort); %delete dubble values
SSE=[];

qn=400; %Number of quantiles to examine
trim=0.01; %initial percentage of observations trimmed; all values of thres between trim and (1-trim) searched
qnt1=qn*trim;
%sq=trim:(1/qn):(trim+(1/qn)*(qn-2*qnt1)); %The quantiles which are examined (0.01, 0.0125, 0.015,...)
sq=trim:(1/qn):(1-trim);
qq=thSort(floor(sq*length(thSort(:,1))));

for x=1:length(qq)
    XBe=zeros(Xrows,Xcols);
    XAb=zeros(Xrows,Xcols);
    for i=1:Xrows
        if thres_group(i,1)<=qq(x,1) 
            XBe(i,:)=X(i,:);
        else
            XAb(i,:)=X(i,:);
        end
    end
    Xthres=[XBe, XAb];
    %Intercepts in model??
    %for j=1:Xsize 
        %if Xthres(j,2)~=0
            %Xthres(j,1)=1;
        %else
            %Xthres(j,6)=1;
        %end
    %end
    mdl{x}=fitlm(Xthres,y,'Intercept',false);
    SSE(x,1)=mdl{x}.SSE;
    Xthres=[];
end
[sse, index]=min(SSE);
percentage=sq(index);
real_index=floor(percentage*size(thSort,1));
thresValues=thSort(real_index);