function [XBelow, XAbove]=split_Xmatrix(groupedX, K, thresValues)

global NT
col=size(groupedX,2)/K;

XBelow=zeros(NT,(col-1));
XAbove=zeros(NT,(col-1));

for k=1:K
    for i=1:NT
        j=(k*(col-1))+(k-(col-1));
        if groupedX(i,j)~=0
            if groupedX(i,j+(col-1))<=thresValues(k)
                XBelow(i,:)=groupedX(i,j:j+(col-2));
            else
                XAbove(i,:)=groupedX(i,j:j+(col-2));
            end
        end
    end
end