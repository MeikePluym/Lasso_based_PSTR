function [LR]=calc_LR_thres_new(thres, X, originalX, y, group, K, thresValues)
global d0 NT T

for i=1:size(thresValues)
    if thresValues(i,1)==max(thresValues)
        thres_true(i,1)=max(d0);
    elseif thresValues(i,1)==min(thresValues)
        thres_true(i,1)=min(d0);
    else
        thres_true(i,1)=d0(2,1);
    end
end

groups=repelem(group,T,1);
SSE_est=zeros(K,1);
SSE_true=zeros(K,1);
NTk=zeros(K,1);

for k=1:K %for the estimated gamma just use the resulting X from each replication
    Xk=[];
    yk=[];
    for i=1:NT
        if groups(i,k)==1
            Xk=[Xk; X(i,:)];
            yk=[yk; y(i,:)];
        end
    end
    theta=(Xk'*Xk)\(Xk'*yk);
    sse=0;
    for i=1:size(Xk,1)
        sse=sse+(yk(i,1)-(Xk(i,:)*theta))^2;
    end
    SSE_est(k,1)=sse;
    NTk(k,1)=size(Xk,1);
end

for k=1:K
    Xk=[];
    yk=[];
    for i=1:NT
        if groups(i,k)==1
            Xk=[Xk; originalX(i,:), thres(i,:)];
            yk=[yk; y(i,:)];
        end
    end 
    elem=size(Xk,2);
    Xkbe=zeros(size(Xk,1),(elem-size(thres,2)));
    Xkab=zeros(size(Xk,1),(elem-size(thres,2)));
    for j=1:size(Xk,1)
        if Xk(j,elem)<=thres_true(k,1)
            Xkbe(j,:)=Xk(j,1:(elem-1));
        else
            Xkab(j,:)=Xk(j,1:(elem-1));
        end
    end
    Xthr=[Xkbe, Xkab];
    theta=(Xthr'*Xthr)\(Xthr'*yk);
    sse=0;
    for i=1:size(Xthr,1)
        sse=sse+(yk(i,1)-(Xthr(i,:)*theta))^2;
    end
    SSE_true(k,1)=sse;
end

this_sigma=zeros(K,1);
for k=1:K
    this_sigma(k,1)=(1/NTk(k,1))*SSE_est(k,1);
end
LR=(SSE_true-SSE_est)./this_sigma;
LR=LR';