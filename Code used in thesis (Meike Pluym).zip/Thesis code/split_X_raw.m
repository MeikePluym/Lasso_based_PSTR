function [X_rawBelow, X_rawAbove]=split_X_raw(originalX_raw, X)
global N T p_val

X_rawBelow=zeros(N*T, p_val);
X_rawAbove=zeros(N*T, p_val);

for i=1:N*T
    if X(i,1:p_val)==0
        X_rawAbove(i,:)=originalX_raw(i,:);
    else
        X_rawBelow(i,:)=originalX_raw(i,:);
    end
end