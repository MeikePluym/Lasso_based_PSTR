clear
global p K_max N T NT

cvx_solver mosek

IC_needed=1;
tol=0.0001;
R=80;
N=55;
T=15;
NT=N*T;
thresValue=0; %initial threshold value (homogenous for groups)
count=0;
equal=0; %numerical convergence criterium
lowest_IC=[];
estimates=0;
K_prev=0;

load('balancedPanelX1995new.mat')
originalX=[cpi, interest, gdp];
y=saving;
thres=balance;


p = 2*size(originalX,2);

K_max=5;
lamb.grid=10;
lamb.min=0.2;
lamb.max=2.0;
lamb_const=lamb.min*(lamb.max/lamb.min).^(((1:lamb.grid)-1)/(lamb.grid-1));
numlam=length(lamb_const);

index=dataset(code, year, y, originalX);
index.Properties.VarNames={'N' 'T' 'y' 'originalX'};

y_raw=y;
originalX_raw=originalX;

for i=1:N %Remove individual fixed effects from X and y
    yi=y(index.N==i);
    mean_yi=mean(yi);
    yi=bsxfun(@minus,yi,mean(yi));
    y(index.N==i)=yi/std(yi,1);
    y_raw(index.N==i)=y(index.N==i)+mean_yi;
    
    originalXi=originalX(index.N==i,:);
    mean_originalXi=mean(originalXi);
    originalXi=bsxfun(@minus,originalXi,mean(originalXi));
    originalX(index.N==i,:)=originalXi./repmat(std(originalXi,1),[T 1]);
    originalX_raw(index.N==i,:)=originalX(index.N==i,:)+repmat(mean(originalXi),[T 1]);
end

X=X_threshold(originalX, thres, thresValue);
X_raw=X_threshold(originalX_raw, thres, thresValue);

ds=dataset(code, year, y, X, y_raw, X_raw);
ds.Properties.VarNames={'N' 'T' 'y' 'X' 'y_raw' 'X_raw'};

while equal==0 && count<=100
    
    %% initial values
    beta_hat0=zeros(N,p);
    for i=1:N
        yi=ds.y(ds.N==i);
        Xi=ds.X(ds.N==i,:);
        beta_hat0(i,:)=regress(yi,Xi);
    end
    
    %% estimation
    TT=T;
    IC_total=ones(K_max, numlam);

    if IC_needed==1
        for ll=1:numlam
            disp(ll)

            a=ds.X\ds.y;
            bias=SPJ_PLS(T, ds.y_raw, ds.X_raw);
            a_corr=2*a-bias;
            IC_total(1,:)=mean((y-X*a_corr).^2);

            for K = 2:K_max
                Q = 999*zeros(K,1);

                lam = lamb_const(ll)*var(y) * T^(-1/3);
                [b_K, hat.a] = PLS_est(N, TT, y, X, beta_hat0, K, lam, R, tol); % estimation
                [~, H.b, ~, group] = report_b( b_K, hat.a, K );
                sum(group)            

                post_b = zeros(N, p);
                post_a = zeros(K, p);
                if K >=2
                    for i = 1:K
                        NN = 1:N;
                        H.group = logical(group);
                        this_group = group(:,i);
                        if sum(this_group) > 0
                            g_index = NN(this_group);
                            g_data = ds( ismember(ds.N, g_index), : );

                            post = post_est_PLS_dynamic(T, g_data);

                            e = g_data.y - g_data.X * post.post_a_corr ;
                            Q(i) = sum( e.^2 );
                            post_b(this_group,:) = repmat(post.post_a_corr', [sum(this_group), 1] );
                        end
                    end
                end


                IC_total(K , ll) = sum(Q) / (N*T)

            end
        end

        %% calculate the IC
        pen = 2/3 * (N*T)^(-.5) * p .* repmat( (1:K_max)', [1 numlam]);
        IC_final = log(IC_total) + pen;
        disp(IC_final)

        [IC_min,ind] = min(IC_final(:));
        [row,col]=ind2sub([size(IC_final,1) size(IC_final,2)],ind); 
        disp('The minimum IC value is: ') 
        disp(IC_min)
        disp('The indices of this minimum are: ')
        disp([row,col])

        lowest_IC=[lowest_IC; [IC_min, row, col]];
    end
    
    %% PLS estimation
    K=row;
    if K_prev==K
        equal=1;
    end
    K_prev=K;
    
    const=lamb_const(col);
    lam = const *var(y) * T^(-1/3);

    [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
    [~, b, ~ , group] = report_b( b_K, a, K );
    
    %% re-estimation of threshold parameters
    [thresValues, groupedX]=X_y_grouped_new(originalX, y, K, group, thres);
    
    %% re-assigning X matrix into below/above threshold
    X=split_Xmatrix_new(originalX, K, thresValues, group, thres);
    X_raw=split_Xmatrix_new(originalX_raw, K, thresValues, group, thres);
    
    ds=dataset(code, year, y, X, y_raw, X_raw);
    ds.Properties.VarNames={'N' 'T' 'y' 'X' 'y_raw' 'X_raw'};
    
    
    count=count+1;
end

disp('K converged to')
K

disp('starting convergence of group membership and estimates')
K_max=K;
estimates_prev=0;
count2=0;
equal2=0;

while equal2==0 && count2<=100
    beta_hat0=zeros(N,p);
    for i=1:N
        yi=ds.y(ds.N==i);
        Xi=ds.X(ds.N==i);
        beta_hat0(i,:)=regress(yi,Xi);
    end

    %% estimation
    TT=T;
    IC_total=ones(K_max,numlam);

    if IC_needed==1
        for ll=1:numlam
            %disp(ll);

            a=ds.X\ds.y;
            bias=SPJ_PLS(T,ds.y_raw,ds.X_raw);
            a_corr=2*a-bias;
            IC_total(1,:)=mean((y-X*a_corr).^2);

            for K=2:K_max
                Q=999*zeros(K,1);

                lam = lamb_const(ll)*var(y) * T^(-1/3);
                [b_K, hat.a] = PLS_est(N, TT, y, X, beta_hat0, K, lam, R, tol); % estimation
                [~, H.b, ~, group] = report_b( b_K, hat.a, K );
                sum(group)            

                post_b = zeros(N, p);
                post_a = zeros(K, p);
                if K >=2
                    for i = 1:K
                        NN = 1:N;
                        H.group = logical(group);
                        this_group = group(:,i);
                        if sum(this_group) > 0
                            g_index = NN(this_group);
                            g_data = ds( ismember(ds.N, g_index), : );

                            post = post_est_PLS_dynamic(T, g_data);

                            e = g_data.y - g_data.X * post.post_a_corr ;
                            Q(i) = sum( e.^2 );
                            post_b(this_group,:) = repmat(post.post_a_corr', [sum(this_group), 1] );
                        end
                    end
                end

                IC_total(K,ll)=sum(Q)/(N*T)

            end
        end
        %% calculate the IC final
        pen = 2/3 * (N*T)^(-.5) * p .* repmat( (1:K_max)', [1 numlam]);
        IC_final = log(IC_total) + pen;
        disp(IC_final)

        [IC_min,ind] = min(IC_final(:));
        [row,col]=ind2sub([size(IC_final,1) size(IC_final,2)],ind); 
        disp('The minimum IC value is: ') 
        disp(IC_min)
        disp('The indices of this minimum are: ')
        disp([row,col])

        lowest_IC=[lowest_IC; [IC_min, row, col]];
    end

    const=lamb_const(col);
    lam = const *var(y) * T^(-1/3);

    [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
    [~, b, ~ , group] = report_b( b_K, a, K );

    K_est=K;
    for k=1:K
        if sum(group(:,k))==0
            K=K-1;
        end
    end
    if K~=K_est
        [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
        [~, b, ~ , group] = report_b( b_K, a, K );
    end
    
    [thresValues, groupedX]=X_y_grouped_new(originalX, y, K, group, thres);
    
    %% re-assigning X matrix into below/above threshold
    X=split_Xmatrix_new(originalX, K, thresValues, group, thres);
    X_raw=split_Xmatrix_new(originalX_raw, K, thresValues, group, thres);
    
    ds=dataset(code, year, y, X, y_raw, X_raw);
    ds.Properties.VarNames={'N' 'T' 'y' 'X' 'y_raw' 'X_raw'};
    
     %% post estimation; comparing estimates
    est_lasso = zeros(p, 6);
    est_post_lasso = zeros(p, 6);

    for i = 1:K
        NN = 1:N;
        group = logical(group);
        this_group = group(:,i);
        g_index = NN(this_group);
        g_data = ds( ismember(ds.N, g_index), : ); % group-specific data
        post = post_est_PLS_dynamic(T, g_data);
        est_post_lasso(:,(3*i-2):(3*i)) =  [post.post_a_corr, post.se, post.test_b];
    end

    estimates=[];
    for k=1:K
        j=(k*3)-2;
        estimates(:,k)=est_post_lasso(:,j);
    end
    estimates=estimates'; 
    estimates=[estimates, thresValues];
    estimates=sortrows(estimates,size(estimates,2));

    equal2=convergence_criterium(tol, estimates_prev, estimates);
    count2=count2+1;

    estimates_prev=estimates;
    
end

 %% final estimation C-Lasso
 disp('Final estimation of estimates')
beta_hat0=zeros(N,p);
    for i=1:N
        yi=ds.y(ds.N==i);
        Xi=ds.X(ds.N==i);
        beta_hat0(i,:)=regress(yi,Xi);
    end

    %% estimation
    TT=T;
    IC_total=ones(K_max,numlam);

    if IC_needed==1
        for ll=1:numlam
            %disp(ll);

            a=ds.X\ds.y;
            bias=SPJ_PLS(T,ds.y_raw,ds.X_raw);
            a_corr=2*a-bias;
            IC_total(1,:)=mean((y-X*a_corr).^2);

            for K=2:K_max
                Q=999*zeros(K,1);

                lam = lamb_const(ll)*var(y) * T^(-1/3);
                [b_K, hat.a] = PLS_est(N, TT, y, X, beta_hat0, K, lam, R, tol); % estimation
                [~, H.b, ~, group] = report_b( b_K, hat.a, K );
                sum(group)            

                post_b = zeros(N, p);
                post_a = zeros(K, p);
                if K >=2
                    for i = 1:K
                        NN = 1:N;
                        H.group = logical(group);
                        this_group = group(:,i);
                        if sum(this_group) > 0
                            g_index = NN(this_group);
                            g_data = ds( ismember(ds.N, g_index), : );

                            post = post_est_PLS_dynamic(T, g_data);

                            e = g_data.y - g_data.X * post.post_a_corr ;
                            Q(i) = sum( e.^2 );
                            post_b(this_group,:) = repmat(post.post_a_corr', [sum(this_group), 1] );
                        end
                    end
                end

                IC_total(K,ll)=sum(Q)/(N*T)

            end
        end
        %% calculate the IC final
        pen = 2/3 * (N*T)^(-.5) * p .* repmat( (1:K_max)', [1 numlam]);
        IC_final = log(IC_total) + pen;
        disp(IC_final)

        [IC_min,ind] = min(IC_final(:));
        [row,col]=ind2sub([size(IC_final,1) size(IC_final,2)],ind); 
        disp('The minimum IC value is: ') 
        disp(IC_min)
        disp('The indices of this minimum are: ')
        disp([row,col])

        lowest_IC=[lowest_IC; [IC_min, row, col]];
    end

    const=lamb_const(col);
    lam = const *var(y) * T^(-1/3);


    [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
    [~, b, ~ , group] = report_b( b_K, a, K );


 %% post estimation; comparing estimates
est_lasso = zeros(p, 6);
est_post_lasso = zeros(p, 6);

for i = 1:K
    NN = 1:N;
    group = logical(group);
    this_group = group(:,i);
    g_index = NN(this_group);
    g_data = ds( ismember(ds.N, g_index), : ); % group-specific data
    post = post_est_PLS_dynamic(T, g_data);
    est_post_lasso(:,(3*i-2):(3*i)) =  [post.post_a_corr, post.se, post.test_b];
end

estimates=[];
for k=1:K
    j=(k*3)-2;
    estimates(:,k)=est_post_lasso(:,j);
end
estimates=estimates'; 
estimates=[estimates, thresValues];
estimates=sortrows(estimates,size(estimates,2));
 

