%function [within_interval]=calc_coverage_prob(estimates, stand_dev, true_vals, thres, X, originalX, y, group)
function [within_interval]=calc_coverage_prob(estimates, stand_dev, true_vals, LR, K)

%for the beta estimates
est=estimates(:,1:size(estimates,2)-1);
sd=stand_dev(:,1:size(stand_dev,2)-1);
true_beta=true_vals(:,1:size(true_vals,2)-1);
num=size(est,2);

num_beta=size(est,1)*size(est,2);

est=reshape(est', [1 num_beta]);
sd=reshape(sd', [1 num_beta]);
true_beta=reshape(true_beta', [1 num_beta]);

val_low=est-(1.96.*sd);
val_high=est+(1.96.*sd);

interval_beta=zeros(1,num_beta);
for i=1:num_beta
    if val_low(1,i)<=true_beta(1,i) && true_beta(1,i)<=val_high(1,i)
        interval_beta(1,i)=1;
    end
end


%for gamma estimates
%LR=calc_LR_thres(thres, X, originalX, y, group);
crit_value=7.35;
interval_gamma=zeros(1,size(LR,2));
for i=1:size(LR,2)
    if LR(1,i)<=crit_value
        interval_gamma(1,i)=1;
    end
end

interval_beta=(reshape(interval_beta,[num,K]))';

within_interval=[];

for k=1:K
    within_interval=[within_interval, interval_beta(k,:)];
    within_interval=[within_interval, interval_gamma(1,k)];
end




