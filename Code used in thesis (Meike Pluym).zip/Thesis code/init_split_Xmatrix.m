function [XBelow, XAbove]= init_split_Xmatrix(X, thres, thresValue)

global NT
XBelow=zeros(NT,size(X,2));
XAbove=zeros(NT,size(X,2));

for i=1:NT %split into below and above threshold
    if thres(i,1)<=thresValue
        XBelow(i,:)=X(i,:);
    else
        XAbove(i,:)=X(i,:);
    end
end