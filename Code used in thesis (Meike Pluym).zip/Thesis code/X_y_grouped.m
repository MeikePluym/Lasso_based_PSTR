function[thresValues, groupedX]=X_y_grouped(originalX, y, K, group, thres)
%Takes into account a K_max of 5
global N T


originalX_thres=[originalX, thres]; 
y1=[]; y2=[]; y3=[]; y4=[]; y5=[];
X1=[]; X2=[]; X3=[]; X4=[]; X5=[];
%X1thresBe=[]; X2thresBe=[]; X3thresBe=[]; X4thresBe=[]; X5thresBe=[];
%X1thresAb=[]; X2thresAb=[]; X3thresAb=[]; X4thresAb=[]; X5thresAb=[];
%X1thres=[]; X2thres=[]; X3thres=[]; X4thres=[]; X5thres=[];

x=size(originalX_thres,2); %is number of x variables
groups=repelem(group,T,1);
%Create matrix with the groups seperated (but all in one matrix)
groupedY=zeros(N,K);
groupedX=zeros(N,K*x);
for k=1:K
    for i=1:N*T
        if groups(i,k)==1
            j=k*(x-1) + (k-(x-1));
            groupedY(i,k)=y(i,:);
            groupedX(i,j:j+(x-1))=originalX_thres(i,:);
        end
    end
end

%Create an X and y matrix per group
for i=1:N*T
    if K==1
        if sum(groupedX(i,1:x))~=0
            X1=[X1; groupedX(i,1:x)];
            y1=[y1; groupedY(i,1)];
        end
    elseif K==2
        if sum(groupedX(i,1:x))~=0
            X1=[X1; groupedX(i,1:x)];
            y1=[y1; groupedY(i,1)];
        elseif sum(groupedX(i,(x+1):2*x))~=0
            X2=[X2; groupedX(i,(x+1):2*x)];
            y2=[y2; groupedY(i,2)];
        end
    elseif K==3
        if sum(groupedX(i,1:x))~=0
            X1=[X1; groupedX(i,1:x)];
            y1=[y1; groupedY(i,1)];
        elseif sum(groupedX(i,(x+1):2*x))~=0
            X2=[X2; groupedX(i,(x+1):2*x)];
            y2=[y2; groupedY(i,2)];
        elseif sum(groupedX(i,(2*x+1):3*x))~=0
            X3=[X3; groupedX(i,(2*x+1):3*x)];
            y3=[y3; groupedY(i,3)];
        end
    elseif K==4
        if sum(groupedX(i,1:x))~=0
            X1=[X1; groupedX(i,1:x)];
            y1=[y1; groupedY(i,1)];
        elseif sum(groupedX(i,(x+1):2*x))~=0
            X2=[X2; groupedX(i,(x+1):2*x)];
            y2=[y2; groupedY(i,2)];
        elseif sum(groupedX(i,(2*x+1):3*x))~=0
            X3=[X3; groupedX(i,(2*x+1):3*x)];
            y3=[y3; groupedY(i,3)];
        elseif sum(groupedX(i,(3*x+1):4*x))~=0
            X4=[X4; groupedX(i,(3*x+1):4*x)];
            y4=[y4; groupedY(i,4)];
        end 
    else
        if sum(groupedX(i,1:x))~=0
            X1=[X1; groupedX(i,1:x)];
            y1=[y1; groupedY(i,1)];
        elseif sum(groupedX(i,(x+1):2*x))~=0
            X2=[X2; groupedX(i,(x+1):2*x)];
            y2=[y2; groupedY(i,2)];
        elseif sum(groupedX(i,(2*x+1):3*x))~=0
            X3=[X3; groupedX(i,(2*x+1):3*x)];
            y3=[y3; groupedY(i,3)];
        elseif sum(groupedX(i,(3*x+1):4*x))~=0
            X4=[X4; groupedX(i,(3*x+1):4*x)];
            y4=[y4; groupedY(i,4)];
        else
            X5=[X5; groupedX(i,(4*x+1):5*x)];
            y5=[y5; groupedY(i,5)];
        end 
    end
end

if K==1
    [~, thresValue1]=thres_values(X1, y1, thres);
    thresValues=[thresValue1];
elseif K==2
    [~, thresValue1]=thres_values(X1, y1, thres);
    [~, thresValue2]=thres_values(X2, y2, thres); 
    thresValues=[thresValue1; thresValue2];
elseif K==3
    [~, thresValue1]=thres_values(X1, y1, thres);
    [~, thresValue2]=thres_values(X2, y2, thres);
    [~, thresValue3]=thres_values(X3, y3, thres); 
    thresValues=[thresValue1; thresValue2; thresValue3];
elseif K==4
    [~, thresValue1]=thres_values(X1, y1, thres);
    [~, thresValue2]=thres_values(X2, y2, thres);
    [~, thresValue3]=thres_values(X3, y3, thres);
    [~, thresValue4]=thres_values(X4, y4, thres);  
    thresValues=[thresValue1; thresValue2; thresValue3; thresValue4];
else
    [~, thresValue1]=thres_values(X1, y1, thres);
    [~, thresValue2]=thres_values(X2, y2, thres);
    [~, thresValue3]=thres_values(X3, y3, thres);
    [~, thresValue4]=thres_values(X4, y4, thres);
    [~, thresValue5]=thres_values(X5, y5, thres);
    thresValues=[thresValue1; thresValue2; thresValue3; thresValue4; thresValue5];
end


%{
if K==1
    for i=1:size(X1,1)
        if X1(i,x)<=thresValue(1)
            X1thresBe=[X1thresBe; X1(i, 1:(x-1))];
            X1thresAb=[X1thresAb; zeros(1,(x-1))];
        else
            X1thresBe=[X1thresBe; zeros(1,(x-1))];
            X1thresAb=[X1thresAb; X1(i,1:(x-1))];
        end
    end
    X1thres=[X1thresBe, X1thresAb];
elseif K==2
    for i=1:size(X1,1)
        if X1(i,x)<=thresValue(1)
            X1thresBe=[X1thresBe; X1(i, 1:(x-1))];
            X1thresAb=[X1thresAb; zeros(1,(x-1))];
        else
            X1thresBe=[X1thresBe; zeros(1,(x-1))];
            X1thresAb=[X1thresAb; X1(i,1:(x-1))];
        end
    end
    for i=1:size(X2,1)
        if X2(i,x)<=thresValue(2)
            X2thresBe=[X2thresBe; X2(i, 1:(x-1))];
            X2thresAb=[X2thresAb; zeros(1,(x-1))];
        else
            X2thresBe=[X2thresBe; zeros(1,(x-1))];
            X2thresAb=[X2thresAb; X2(i,1:(x-1))];
        end
    end
    X1thres=[X1thresBe, X1thresAb];
    X2thres=[X2thresBe, X2thresAb];
elseif K==3
    for i=1:size(X1,1)
        if X1(i,x)<=thresValue(1)
            X1thresBe=[X1thresBe; X1(i, 1:(x-1))];
            X1thresAb=[X1thresAb; zeros(1,(x-1))];
        else
            X1thresBe=[X1thresBe; zeros(1,(x-1))];
            X1thresAb=[X1thresAb; X1(i,1:(x-1))];
        end
    end
    for i=1:size(X2,1)
        if X2(i,x)<=thresValue(2)
            X2thresBe=[X2thresBe; X2(i, 1:(x-1))];
            X2thresAb=[X2thresAb; zeros(1,(x-1))];
        else
            X2thresBe=[X2thresBe; zeros(1,(x-1))];
            X2thresAb=[X2thresAb; X2(i,1:(x-1))];
        end
    end
    for i=1:size(X3,1)
        if X3(i,x)<=thresValue(3)
            X3thresBe=[X3thresBe; X3(i, 1:(x-1))];
            X3thresAb=[X3thresAb; zeros(1,(x-1))];
        else
            X3thresBe=[X3thresBe; zeros(1,(x-1))];
            X3thresAb=[X3thresAb; X3(i,1:(x-1))];
        end
    end
    X1thres=[X1thresBe, X1thresAb];
    X2thres=[X2thresBe, X2thresAb];
    X3thres=[X3thresBe, X3thresAb];
elseif K==4
    for i=1:size(X1,1)
        if X1(i,x)<=thresValue(1)
            X1thresBe=[X1thresBe; X1(i, 1:(x-1))];
            X1thresAb=[X1thresAb; zeros(1,(x-1))];
        else
            X1thresBe=[X1thresBe; zeros(1,(x-1))];
            X1thresAb=[X1thresAb; X1(i,1:(x-1))];
        end
    end
    for i=1:size(X2,1)
        if X2(i,x)<=thresValue(2)
            X2thresBe=[X2thresBe; X2(i, 1:(x-1))];
            X2thresAb=[X2thresAb; zeros(1,(x-1))];
        else
            X2thresBe=[X2thresBe; zeros(1,(x-1))];
            X2thresAb=[X2thresAb; X2(i,1:(x-1))];
        end
    end
    for i=1:size(X3,1)
        if X3(i,x)<=thresValue(3)
            X3thresBe=[X3thresBe; X3(i, 1:(x-1))];
            X3thresAb=[X3thresAb; zeros(1,(x-1))];
        else
            X3thresBe=[X3thresBe; zeros(1,(x-1))];
            X3thresAb=[X3thresAb; X3(i,1:(x-1))];
        end
    end
    for i=1:size(X4,1)
        if X4(i,x)<=thresValue(4)
            X4thresBe=[X4thresBe; X4(i, 1:(x-1))];
            X4thresAb=[X4thresAb; zeros(1,(x-1))];
        else
            X4thresBe=[X4thresBe; zeros(1,(x-1))];
            X4thresAb=[X4thresAb; X4(i,1:(x-1))];
        end
    end
    X1thres=[X1thresBe, X1thresAb];
    X2thres=[X2thresBe, X2thresAb];
    X3thres=[X3thresBe, X3thresAb];
    X4thres=[X4thresBe, X4thresAb];
elseif K==5
    for i=1:size(X1,1)
        if X1(i,x)<=thresValue(1)
            X1thresBe=[X1thresBe; X1(i, 1:(x-1))];
            X1thresAb=[X1thresAb; zeros(1,(x-1))];
        else
            X1thresBe=[X1thresBe; zeros(1,(x-1))];
            X1thresAb=[X1thresAb; X1(i,1:(x-1))];
        end
    end
    for i=1:size(X2,1)
        if X2(i,x)<=thresValue(2)
            X2thresBe=[X2thresBe; X2(i, 1:(x-1))];
            X2thresAb=[X2thresAb; zeros(1,(x-1))];
        else
            X2thresBe=[X2thresBe; zeros(1,(x-1))];
            X2thresAb=[X2thresAb; X2(i,1:(x-1))];
        end
    end
    for i=1:size(X3,1)
        if X3(i,x)<=thresValue(3)
            X3thresBe=[X3thresBe; X3(i, 1:(x-1))];
            X3thresAb=[X3thresAb; zeros(1,(x-1))];
        else
            X3thresBe=[X3thresBe; zeros(1,(x-1))];
            X3thresAb=[X3thresAb; X3(i,1:(x-1))];
        end
    end
    for i=1:size(X4,1)
        if X4(i,x)<=thresValue(4)
            X4thresBe=[X4thresBe; X4(i, 1:(x-1))];
            X4thresAb=[X4thresAb; zeros(1,(x-1))];
        else
            X4thresBe=[X4thresBe; zeros(1,(x-1))];
            X4thresAb=[X4thresAb; X4(i,1:(x-1))];
        end
    end
    for i=1:size(X5,1)
        if X5(i,x)<=thresValue(5)
            X5thresBe=[X5thresBe; X5(i, 1:(x-1))];
            X5thresAb=[X5thresAb; zeros(1,(x-1))];
        else
            X5thresBe=[X5thresBe; zeros(1,(x-1))];
            X5thresAb=[X5thresAb; X5(i,1:(x-1))];
        end
    end
    X1thres=[X1thresBe, X1thresAb];
    X2thres=[X2thresBe, X2thresAb];
    X3thres=[X3thresBe, X3thresAb];
    X4thres=[X4thresBe, X4thresAb];
    X5thres=[X5thresBe, X5thresAb];
end
%}






%INPUT THRESHOLD REGRESSION FOR EACH OF THE GROUPS
