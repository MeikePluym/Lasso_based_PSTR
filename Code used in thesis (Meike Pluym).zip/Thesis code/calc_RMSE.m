function [RMSE]=calc_RMSE(param_bias, num_replications)

sq_error=param_bias.^2;
sum_sq=sum(sq_error)./num_replications;

RMSE=sqrt(sum_sq);