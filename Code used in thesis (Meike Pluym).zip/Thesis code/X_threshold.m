function [X]=X_threshold(originalX, thres, thresValue)
global NT p

X=zeros(NT, p);
for i=1:NT
    X(i,1:(p/2))=originalX(i,:);
    %if thres(i,1)<=thresValue
    if thres(i,1)>thresValue
        X(i,(p/2)+1:p)=originalX(i,:);
    end
end