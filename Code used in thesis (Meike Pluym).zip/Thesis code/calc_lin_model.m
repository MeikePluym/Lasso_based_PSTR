function [est_from_lin, sd_from_lin]=calc_lin_model(X,y,group)
global T

groups=repelem(group,T,1);
est_from_lin=zeros(2,3);

X1=[]; X2=[]; X3=[];
y1=[]; y2=[]; y3=[];

for i=1:size(groups,1)
    if groups(i,1)==1
        X1=[X1; X(i,:)];
        y1=[y1; y(i,:)];
    elseif groups(i,2)==1
        X2=[X2; X(i,:)];
        y2=[y2; y(i,:)];
    else
        X3=[X3; X(i,:)];
        y3=[y3; y(i,:)];
    end
end

mdl1=fitlm(X1, y1, 'Intercept', false);
mdl2=fitlm(X2, y2, 'Intercept', false);
mdl3=fitlm(X3, y3, 'Intercept', false);

est_from_lin(:,1)=table2array(mdl1.Coefficients(:,1));
est_from_lin(:,2)=table2array(mdl2.Coefficients(:,1));
est_from_lin(:,3)=table2array(mdl3.Coefficients(:,1));

sd_from_lin(:,1)=table2array(mdl1.Coefficients(:,2));
sd_from_lin(:,2)=table2array(mdl2.Coefficients(:,2));
sd_from_lin(:,3)=table2array(mdl3.Coefficients(:,2));

