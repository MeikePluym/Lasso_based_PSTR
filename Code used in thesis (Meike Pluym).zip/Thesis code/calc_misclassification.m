function misclass=calc_misclassification(group, originalGroup)
global N

num=floor(size(group,1)/3);
sum1=zeros(1,3);
sum2=zeros(1,3);
sum3=zeros(1,3);
groups=zeros(N,3);

for i=1:num
    sum1=sum1+group(i,:);
end
for i=num:(num*2)
    sum2=sum2+group(i,:);
end
for i=(num*2):(num*3)
    sum3=sum3+group(i,:);
end

[~,i1]=max(sum1);
[~,i2]=max(sum2);
[~,i3]=max(sum3);

if i1~=i2 && i2~=i3 && i1~=i3
    for i=1:3
        if i1==i
            groups(:,i)=group(:,1);
        end
        if i2==i
            groups(:,i)=group(:,2);         
        end
        if i3==i
            groups(:,i)=group(:,3);
        end
    end
end

misclass=0;
group_allocation=zeros(N,1);
for i=1:N
    for k=1:size(groups,2)
        if groups(i,k)==1
            group_allocation(i,1)=k;
        end
    end
end

for i=1:N
    if group_allocation(i,1)==originalGroup(i,1)
        misclass=misclass;
    else
        misclass=misclass+1;
    end
end
misclass=misclass/N;

if misclass>0.5
    misclass=1-misclass;
end

