% Master file for simulation procedure and fit measures
% Meike Pluym (2020)

clear
global p K_max N T NT p_val N_cut a0 d0

cvx_solver mosek

IC_needed=1;
tol=0.0001;
R=80;
N=100;
T=60;
p_val=1; %number of parameters (excluding group/threshold)
NT=N*T;
thresValue=1;
lowest_IC=[];

N_cut=N*[0.3, 0.6, 1];
constant=NT^(-0.1);
a0=[1, 1+constant; 1.75, 1.75+constant; 2.5, 2.5+constant]; 
d0=[0.5; 1; 1.5];

true_vals=[a0, d0];

num_replications=100;
num_params=numel(a0)+numel(d0);
param_bias=[];
param_bias2=[];
RMSE=zeros(1,num_params);
CP=zeros(1,num_params);
CP2=zeros(1, num_params);
num_groups=zeros(num_replications,1);
in_interval=[];
in_interval2=[];
misclassification=[];

%% start of simulation;
for r=1:num_replications
    disp('Starting replication: '+r)
    r
    
    count=0;
    equal=0;
    equal2=0;
    K_prev=0;
    thresValue=0;
    lowest_IC=[];
    
    [y,X,Q,originalGroup,y_raw, X_raw]=DGP2(N,T);
    originalX=X;
    originalX_raw=X_raw;
    thres=Q;
    code=repelem((1:N)',T);
    year=repmat((1:T)',N,1);
    
    
    
    p=2*size(originalX,2);
    
    K=1;
    group=ones(N,1);
   
    [thresValues, groupedX]=X_y_grouped(originalX, y, K, group, thres);
    
    
    [XBelow, XAbove]=init_split_Xmatrix(originalX, thres, thresValues);
    X=[XBelow, XAbove];
    
    [X_rawBelow, X_rawAbove]=init_split_Xmatrix(originalX_raw, thres, thresValues);
    X_raw=[X_rawBelow, X_rawAbove];
    disp('DGP completed')
    
    
    K_max=5;
    lamb.grid=10;
    lamb.min=0.2;
    lamb.max=2.0;
    lamb_const=lamb.min * (lamb.max / lamb.min ).^( ( (1:lamb.grid) - 1) /( lamb.grid -1 ) ); % the constant for lambda. very important!!
    numlam = length(lamb_const);
    
    %% start of C-Lasso based PSTR algorithm
    while equal==0 && count<=5
        disp('Starting iteration of algorithm: ')
        count
        
        ds = dataset( code, year, y, X, y_raw, X_raw );
        ds.Properties.VarNames = {'N'  'T'  'y'  'X' 'y_raw' 'X_raw'};
        
        %% initial values
        beta_hat0=zeros(N,p);
        for i=1:N
            yi=ds.y(ds.N==i);
            Xi=ds.X(ds.N==i);
            beta_hat0(i,:)=regress(yi,Xi);
        end
        
        %% estimation
        TT=T;
        IC_total=ones(K_max,numlam);
        
        if IC_needed==1
            for ll=1:numlam
                %disp(ll);
                
                a=ds.X\ds.y;
                bias=SPJ_PLS(T,ds.y_raw,ds.X_raw);
                a_corr=2*a-bias;
                IC_total(1,:)=mean((y-X*a_corr).^2);
                
                for K=2:K_max
                    Q=999*zeros(K,1);
                    
                    lam = lamb_const(ll)*var(y) * T^(-1/3);
                    [b_K, hat.a] = PLS_est(N, TT, y, X, beta_hat0, K, lam, R, tol); % estimation
                    [~, H.b, ~, group] = report_b( b_K, hat.a, K );
                    sum(group)            

                    post_b = zeros(N, p);
                    post_a = zeros(K, p);
                    if K >=2
                        for i = 1:K 
                            NN = 1:N;
                            H.group = logical(group);
                            this_group = group(:,i);
                            if sum(this_group) > 0
                                g_index = NN(this_group);
                                g_data = ds( ismember(ds.N, g_index), : );

                                post = post_est_PLS_dynamic(T, g_data);
                        
                                e = g_data.y - g_data.X * post.post_a_corr ;
                                Q(i) = sum( e.^2 );
                                post_b(this_group,:) = repmat(post.post_a_corr', [sum(this_group), 1] );
                            end
                        end
                    end
                    
                    IC_total(K,ll)=sum(Q)/(N*T)
                    
                end
            end
            
            %% calculate the IC final
            pen = 2/3 * (N*T)^(-.5) * p .* repmat( (1:K_max)', [1 numlam]);
            IC_final = log(IC_total) + pen;
            disp(IC_final)

            [IC_min,ind] = min(IC_final(:));
            [row,col]=ind2sub([size(IC_final,1) size(IC_final,2)],ind); 
            disp('The minimum IC value is: ') 
            disp(IC_min)
            disp('The indices of this minimum are: ')
            disp([row,col])

            lowest_IC=[lowest_IC; [IC_min, row, col]];
            
        end
        
        %% PLS estimation
        K=row;
        if K_prev==K
            equal=1;
        end
        K_prev=K;
        
        const=lamb_const(col);
        lam = const *var(y) * T^(-1/3);

        [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
        [~, b, ~ , group] = report_b( b_K, a, K );
        
        %% re-estimation of threshold values
        [thresValues, groupedX]=X_y_grouped(originalX, y, K, group, thres);
        
        %% re-assigning X matrix
        [XBelow, XAbove]=split_Xmatrix(groupedX, K, thresValues);
        X=[XBelow, XAbove];
        
        [X_rawBelow, X_rawAbove]=split_X_raw(originalX_raw,X);
        X_raw=[X_rawBelow, X_rawAbove];

        ds=dataset(code, year, y, X, y_raw, X_raw);
        ds.Properties.VarNames={'N' 'T' 'y' 'X' 'y_raw' 'X_raw'};


        count=count+1;
    end
    disp('K converged to: ')
    K
    num_groups(r)=K;
    
    if K==3
        disp('starting convergence of group membership and estimates')
        K_max=K;
        estimates_prev=0;
        count2=0;

        %% updating the threshold and groups until convergence    
        while equal2==0 && count2<=15
            %% initial values
            beta_hat0=zeros(N,p);
            for i=1:N
                yi=ds.y(ds.N==i);
                Xi=ds.X(ds.N==i);
                beta_hat0(i,:)=regress(yi,Xi);
            end

            %% estimation
            TT=T;
            IC_total=ones(1,numlam);

            if IC_needed==1
                for ll=1:numlam
                    %disp(ll);

                    a=ds.X\ds.y;
                    bias=SPJ_PLS(T,ds.y_raw,ds.X_raw);
                    a_corr=2*a-bias;
                    Q=999*zeros(1,1);

                    lam = lamb_const(ll)*var(y) * T^(-1/3);
                    [b_K, hat.a] = PLS_est(N, TT, y, X, beta_hat0, K, lam, R, tol); % estimation
                    [~, H.b, ~, group] = report_b( b_K, hat.a, K );
                    sum(group)            

                    post_b = zeros(N, p);
                    post_a = zeros(K, p);
                    if K >=2
                        for i = 1:K
                            NN = 1:N;
                            H.group = logical(group);
                            this_group = group(:,i);
                            if sum(this_group) > 0
                                g_index = NN(this_group);
                                g_data = ds( ismember(ds.N, g_index), : );

                                post = post_est_PLS_dynamic(T, g_data);

                                e = g_data.y - g_data.X * post.post_a_corr ;
                                Q(i) = sum( e.^2 );
                                post_b(this_group,:) = repmat(post.post_a_corr', [sum(this_group), 1] );
                            end
                        end
                    end

                    IC_total(1,ll)=sum(Q)/(N*T)

                    
                end
                %% calculate the IC final
                pen = 2/3 * (N*T)^(-.5) * p .* repmat( (1:K_max)', [1 numlam]);
                pen=pen(K,:);
                IC_final = log(IC_total) + pen;
                disp(IC_final)

                [IC_min,ind] = min(IC_final(:));
                [row,col]=ind2sub([size(IC_final,1) size(IC_final,2)],ind); 
                disp('The minimum IC value is: ') 
                disp(IC_min)
                disp('The indices of this minimum are: ')
                disp([row,col])

                lowest_IC=[lowest_IC; [IC_min, row, col]];
            end
            
            const=lamb_const(col);
            lam = const *var(y) * T^(-1/3);
            
            
            [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
            [~, b, ~ , group] = report_b( b_K, a, K );
            
            K_est=K;
            for k=1:K
                if sum(group(:,k))==0
                    K=K-1;
                    count2=count2-1;
                end
            end
            if K~=K_est
                [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
                [~, b, ~ , group] = report_b( b_K, a, K );
            end

            %% re-estimation of threshold values
            [thresValues, groupedX]=X_y_grouped(originalX, y, K, group, thres);

            %% re-assigning X matrix
            
            [XBelow, XAbove]=split_Xmatrix(groupedX, K, thresValues);
            X=[XBelow, XAbove];
            
            [X_rawBelow, X_rawAbove]=split_X_raw(originalX_raw,X);
            X_raw=[X_rawBelow, X_rawAbove];

            ds=dataset(code, year, y, X, y_raw, X_raw);
            ds.Properties.VarNames={'N' 'T' 'y' 'X' 'y_raw' 'X_raw'};

            %% post estimation; comparing estimates
            est_lasso = zeros(p, 6);
            est_post_lasso = zeros(p, 6);

            for i = 1:K
                NN = 1:N;
                group = logical(group);
                this_group = group(:,i);
                g_index = NN(this_group);
                g_data = ds( ismember(ds.N, g_index), : );
                post = post_est_PLS_dynamic(T, g_data);
                est_post_lasso(:,(3*i-2):(3*i)) =  [post.post_a_corr, post.se, post.test_b];
            end

            estimates=[];
            for k=1:K
                j=(k*3)-2;
                estimates(:,k)=est_post_lasso(:,j);
            end
            estimates=estimates'; 
            estimates=[estimates, thresValues];
            estimates=sortrows(estimates,size(estimates,2));

            equal2=convergence_criterium(tol, estimates_prev, estimates);
            count2=count2+1;

            estimates_prev=estimates;
        end
        
        %% final estimation C-Lasso
            beta_hat0=zeros(N,p);
            for i=1:N
                yi=ds.y(ds.N==i);
                Xi=ds.X(ds.N==i);
                beta_hat0(i,:)=regress(yi,Xi);
            end

            %% estimation
            TT=T;
            IC_total=ones(1,numlam);

            if IC_needed==1
                for ll=1:numlam
                    %disp(ll);

                    a=ds.X\ds.y;
                    bias=SPJ_PLS(T,ds.y_raw,ds.X_raw);
                    a_corr=2*a-bias;
                    

                    
                    Q=999*zeros(K,1);

                    lam = lamb_const(ll)*var(y) * T^(-1/3);
                    [b_K, hat.a] = PLS_est(N, TT, y, X, beta_hat0, K, lam, R, tol); % estimation
                    [~, H.b, ~, group] = report_b( b_K, hat.a, K );
                    sum(group)            

                    post_b = zeros(N, p);
                    post_a = zeros(K, p);

                        for i = 1:K
                            NN = 1:N;
                            H.group = logical(group);
                            this_group = group(:,i);
                            if sum(this_group) > 0
                                g_index = NN(this_group);
                                g_data = ds( ismember(ds.N, g_index), : );

                                post = post_est_PLS_dynamic(T, g_data);

                                e = g_data.y - g_data.X * post.post_a_corr ;
                                Q(i) = sum( e.^2 );
                                post_b(this_group,:) = repmat(post.post_a_corr', [sum(this_group), 1] );
                            end
                        end
                        

                        IC_total(1,ll)=sum(Q)/(N*T)

                    
                end
                %% calculate the IC final
                pen = 2/3 * (N*T)^(-.5) * p .* repmat( (1:K_max)', [1 numlam]);
                pen=pen(K,:);
                IC_final = log(IC_total) + pen;
                disp(IC_final)

                [IC_min,ind] = min(IC_final(:));
                [row,col]=ind2sub([size(IC_final,1) size(IC_final,2)],ind); 
                disp('The minimum IC value is: ') 
                disp(IC_min)
                disp('The indices of this minimum are: ')
                disp([row,col])

                lowest_IC=[lowest_IC; [IC_min, row, col]];
            end
            
            const=lamb_const(col);
            lam = const *var(y) * T^(-1/3);
            
            
            [b_K, a] = PLS_est(N, T, y, X, beta_hat0, K, lam, R, tol);
            [~, b, ~ , group] = report_b( b_K, a, K );
            
            [est_from_lin, sd_from_lin]=calc_lin_model(X,y,group);
            est_from_lin=est_from_lin'; sd_from_lin=sd_from_lin';
            est_from_lin=[est_from_lin, thresValues]; sd_from_lin=[sd_from_lin, thresValues];
            est_from_lin=sortrows(est_from_lin,size(est_from_lin,2)); sd_from_lin=sortrows(sd_from_lin,size(sd_from_lin,2));
        

         %% post estimation; comparing estimates
        est_lasso = zeros(p, 6);
        est_post_lasso = zeros(p, 6);

        for i = 1:K
            NN = 1:N;
            group = logical(group);
            this_group = group(:,i);
            g_index = NN(this_group);
            g_data = ds( ismember(ds.N, g_index), : ); % group-specific data
            post = post_est_PLS_dynamic(T, g_data);
            est_post_lasso(:,(3*i-2):(3*i)) =  [post.post_a_corr, post.se, post.test_b];
        end

        estimates=[];
        for k=1:K
            j=(k*3)-2;
            estimates(:,k)=est_post_lasso(:,j);
        end
        estimates=estimates'; 
        estimates=[estimates, thresValues];
        estimates=sortrows(estimates,size(estimates,2));

        %% simulation measures
        estimates=[];
        this_bias=[];
        this_bias2=[];
        stand_dev=[];
        for k=1:K
            j=(k*3)-(2); %dit veranderd
            estimates(:,k)=est_post_lasso(:,j);
            stand_dev(:,k)=est_post_lasso(:,j+1);
        end
        estimates=estimates'; stand_dev=stand_dev';
        estimates=[estimates, thresValues]; stand_dev=[stand_dev, thresValues];
        estimates=sortrows(estimates,size(estimates,2)); stand_dev=sortrows(stand_dev,size(stand_dev,2));

        this_bias=(true_vals-estimates)';
        this_bias2=(true_vals-est_from_lin)';
        this_bias=reshape(this_bias,[1 num_params]);
        this_bias2=reshape(this_bias2, [1 num_params]);
        param_bias=[param_bias; this_bias]; 
        param_bias2=[param_bias2, this_bias2];

        
        LR=calc_LR_thres_new(thres, X, originalX, y, group, K, thresValues);

        disp('The LR values are: ')
        disp(LR)
        

        within_interval=calc_coverage_prob(estimates, stand_dev, true_vals, LR, K);
        within_interval2=calc_coverage_prob(est_from_lin, sd_from_lin, true_vals, LR, K);
        in_interval=[in_interval; within_interval];
        in_interval2=[in_interval2; within_interval2];
        
        misclas=calc_misclassification(group, originalGroup);
        misclassification=[misclassification; misclas];
    
    end
end

%% final measures
disp('Simulation completed, calculating measures')

num_K=zeros(1,K);
for k=1:K
    num_K(1,k)=sum(num_groups==k);    
end
percentage_K=num_K./num_replications; %PERCENTAGE ESTIMATED K
disp('The percentage of times that the estimated K took value are:')
disp(percentage_K)

bias_values=mean(param_bias); %BIAS VALUES
disp('The parameter biases are:')
disp(bias_values)

bias_values2=mean(param_bias2);

[RMSE]=calc_RMSE(param_bias, size(param_bias,1)); %RMSE VALUES
disp('The RMSE values are:')
disp(RMSE)

CP=sum(in_interval)./size(in_interval,1); %COVERAGE PROBABILITY
disp('The coverage probability is: ')
disp(CP)

CP2=sum(in_interval2)./size(in_interval2,1);

misclassification_rate=mean(misclassification); %MISCLASSIFICATION RATE
disp('The misclassification rate is: ')
disp (misclassification_rate)