function [interval]=calc_CP(estimates,stand_dev,true_vals,y, X, group, originalX, thres)
global K d0

num_params_est=size(estimates,1)*size(estimates,2);

est=reshape(estimates', [1 num_params_est]);
sd=reshape(stand_dev', [1 num_params_est]);
vals=reshape(true_vals', [1 num_params_est]);
val_low=[];
val_high=[];
interval=zeros(1,num_params_est);
num=num_params_est./K;

LR=conf_interval_threshold(d0, y, K, X, group, originalX, thres);
for k=1:K
    vals(k*K)=LR(k,1);
end

for k=1:K
    j=(k*K)-(K-1);
    for i=1:(num-1)
        val_low(k,i)=est(1,j+(i-1))-(1.96*sd(1,j+(i-1)));
        val_high(k,i)=est(1,j+(i-1))+(1.96*sd(1,j+(i-1)));
    end
    val_low(k,num)=-inf; %CRITICAL VALUE VERANDEREN VOOR SIGNIFICANCE VAN THREHOLDS
    val_high(k,num)=7.35;
    %val_low(k,num)=est(1,j+(num-1))-(1.96*sd(1,j+(i-1))); %CRITICAL VALUE VERANDEREN VOOR SIGNIFICANCE VAN THREHOLDS
    %val_high(k,num)=est(1,j+(num-1))+(1.96*sd(1,j+(i-1)));
end

val_low=reshape(val_low', [1 num_params_est]);
val_high=reshape(val_high', [1 num_params_est]);

for i=1:num_params_est
    if val_low(1,i)<=vals(1,i) && vals(1,i)<=val_high(1,i)
        interval(1,i)=1;
    end
end

%{
for k=1:K
    j=(k*K)-(K-1);
    for i=1:num
        if interval(1,j+(i-1))==1
            interval(1,j+(i-1))=Nk(k)/N;
        end        
    end
end
%}


