function[y, X, Q, group, y_raw, X_raw]=DGP2(N,T)

global p_val N_cut a0 d0 
%N_cut; percentage per group, 
%a0; slope coefficients
%d0; threshold coefficients



sigma_x=1;
sigma_q=1;
sigma_e=1;

y=zeros(T, N);
X=zeros(T, N, p_val);
Q=zeros(T, N);

y_raw=zeros(T,N);
X_raw=zeros(T, N, p_val);

K=length(N_cut); %number of groups
group=[];

for i=1:N
    kk=1:K;
    k=min(kk(i<=N_cut));
    
    group=[group,k];
    XX=random('Normal', 0, sigma_x, T, p_val);
    e=random('Normal', 0, sigma_e, T, 1);
    eps=((0.5+(0.1.*(XX.^2))).^(1/2)).*e;
    QQ=random('Normal', 1, sigma_q, T, 1); %MOET DIT EVEN PER GROEP DOEN ZODAT ELKE GROEP ANDERE THRESHOLD PARAMETER HEEFT
    yy=zeros(T,1);
    for t=1:T
        if QQ(t)<=d0(k)
            yy(t,1)=XX(t,:)*a0(k, 1:p_val)'+eps(t,:); %y(t,i) veranderd naar y(t,1)
            %y(t,i)=XX(t,:)*a0(k, 1)'+e(t);
        else
            yy(t,1)=XX(t,:)*a0(k, p_val+1:2*p_val)'+eps(t,:);
            %y(t,i)=XX(t,:)*a0(k, 2)'+e(t);
        end
    end
    
    X_raw(:,i,:)=permute(XX, [1 3 2]);
    y_raw(:,i)=yy;
    
    %X(:, i, :)=permute(XX, [1 3 2]); DEZE
    Q(:, i, :)=permute(QQ, [1 3 2]); %demeanen weer aangezet
    %y(:, i)=yy; DEZE
    X(:, i, :)=permute(demean(XX), [1 3 2]); 
    y(:, i)=demean(yy);
end
y=reshape(y, T*N, 1);
X=reshape(X, T*N, p_val);
Q=reshape(Q, T*N, 1);
group=group';

y_raw=reshape(y_raw, T*N, 1);
X_raw=reshape(X_raw, T*N, p_val);
end